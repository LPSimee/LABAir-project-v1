// Script principale
let CAIO = document.querySelector("nav.contenitore-mini ul li:nth-of-type(2) a");
console.log(CAIO.innerHTML);

CAIO.addEventListener("hover", ()=>{
    $("#contenitore-mini-voci").css("dispay", "block");
});