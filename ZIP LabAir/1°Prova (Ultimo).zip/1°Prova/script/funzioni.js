// Funzioni.js


// Gestione bottoni slider
const slider = $(".slider ul");
const bottoniSinistra = $(".bottone-slider.sinistra");
const bottoniDestra = $(".bottone-slider.destra");
console.log("Slider" , slider);
console.log("Bottoni sinistra", bottoniSinistra);
console.log("Bottoni destra", bottoniDestra);

for(let i=0; i<slider.length; i++){
    let maxScrollWidth = slider[i].scrollWidth - slider[i].clientWidth;
    console.log("scrollWidth " + i + ":", slider[i].scrollWidth, slider[i].clientWidth)
    console.log("maxScrollSlider: ", maxScrollWidth)
    
    /* Per lo scorrimento dallo scrollbar */
    $(slider[i]).scroll(()=>{
        console.log(slider[i].scrollLeft);
        if(slider[i].scrollLeft == 0){
            console.log(slider[i].scrollLeft);
            bottoniSinistra[i].disabled = true;
        } else bottoniSinistra[i].disabled = false;

        if(slider[i].scrollLeft == maxScrollWidth || slider[i].scrollLeft == (slider[i].scrollWidth - slider[i].clientWidth)){
            console.log(slider[i].scrollLeft);
            bottoniDestra[i].disabled = true;
        } else bottoniDestra[i].disabled = false;
        
    });
    
    $(bottoniSinistra[i]).click(()=>{
        console.log("Tasto sinistro");
        
        if(slider[i].scrollLeft == 0){
            bottoniSinistra[i].disabled = true;
        } else {
            bottoniSinistra[i].disabled = false;
            switch(i){

                case 0:
                    slider[i].scrollLeft -= (maxScrollWidth / 8) + 12;
                    break;
                case 1:
                    slider[i].scrollLeft -= (maxScrollWidth / 7) + 12;
                    break;
                case 2:
                    slider[i].scrollLeft -= (maxScrollWidth / 6) + 12;
                    break;
                default:
                    slider[i].scrollLeft -= 300;
            }
            
        }
        
    });

    $(bottoniDestra[i]).click(()=>{
        console.log("Tasto destro");

        if(slider[i].scrollLeft >= maxScrollWidth){
            bottoniDestra[i].disabled = true;
        } else {
            bottoniDestra[i].disabled = false;
            switch(i){

                case 0:
                    slider[i].scrollLeft += (maxScrollWidth / 9) + 12;
                    break;
                case 1:
                    slider[i].scrollLeft += (maxScrollWidth / 7) + 12;
                    break;
                case 2:
                    slider[i].scrollLeft += (maxScrollWidth / 6) + 12;
                    break;
                default:
                    slider[i].scrollLeft += 300;
            }
            
        }
    });
}