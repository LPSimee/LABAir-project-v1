// Gestire il controllo degli input con le regex

const regex = [
    /^[A-Za-zàèéìòóùüÀÈÉÌÒÓÙÜ' ]{2,50}$/, /* Nome */
    /^[A-Za-zàèéìòóùüÀÈÉÌÒÓÙÜ' ]{2,50}(?: [A-Za-zàèéìòóùüÀÈÉÌÒÓÙÜ' ]{2,50})+$/, /* Cognome */
    /^(Via|Viale|Corso|Piazza|Strada|Largo|Lungomare|Piazzale)\s+[A-Za-zàèéìòóùüÀÈÉÌÒÓÙÜ\s]+(\s\d+[A-Za-z]?)?$/, /* Indirizzo */
    /^\d{5}$/, /* CAP */
    /^[A-Za-zàèéìòóùüÀÈÉÌÒÓÙÜ' ]{2,100}$/, /* Città */
    /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, /* E-mail */
    /^\[0-9]{6,12}$/

 /* Telefono */
]   