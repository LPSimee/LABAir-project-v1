// // Script principale
// let CAIO = document.querySelector("#mini-header nav ul li:nth-child(2)");
// console.log(CAIO.innerHTML);

// $(CAIO).hover(()=>{
//     $("#contenitore-mini-voci")
//     .css("opacity", "1")
//     .css("z-index", "100")
//     // .css("transition", "opacity 250ms, transform 250ms");
// });

// console.log($("#contenitore-mini-voci").html());

// let miniVoci = $("#contenitore-mini-voci");

// $(miniVoci).mouseout(()=>{
//     $(miniVoci)
//     .css("opacity", "0")
//     .css("z-index", "-1");
// });

const vociHeader = $("li .voce-grande-header a"); // Voci <li> di #header-nav
let cvociHeader = $(".contenitore-voci-header"); // Contenitore delle minivoci degli <li>
let minivoci = $(".voce-header");

console.log(vociHeader, cvociHeader, minivoci)
// for(let i=0; i<vociHeader.length;i++){
//     console.log(vociHeader[i].innerHTML);
//     $(vociHeader[i]).hover(()=>{
//         console.log("HOVER" + i);
        
//         cvociHeader.css(
//             {
//                 "height":"340px",
//                 "opacity":"1",
//                 "z-index":"100",
//                 "top":"96px",
//             });
    
//         // ciao.animate({}, 300);
//         // $("#voce-header-uomo").css("opacity","1").fadeIn(350);
    
//         // $(bb[1]).mouseleave(()=>{
//         //     console.log("MOUSELEAVE")
//         //     ciao.css(
//         //         {
//         //             "height":"0",
//         //             "opacity":"0"
//         //         }
//         //     );
//         //     // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
//         // });
//         $(minivoci[i-1]).css({
//             "opacity":"0",
//             "display":"none",
//         });
//         $(minivoci[i]).css({
//             "opacity":"1",
//             "display":"flex",
//         });

//         $(minivoci[i+1]).css({
//             "opacity":"0",
//             "display":"none",
//         });
        
//     });
    
//     $(cvociHeader).mouseleave(()=>{
//         console.log("MOUSELEAVE")
//         $(minivoci[i]).css({
//             "opacity":"0",
//             "display":"none",
//         });
        
//         cvociHeader.css(
//             {
//                 "height":"0",
//                 "opacity":"0"
//             }
//         );
//         // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
//     });
// }





/* $(bb[1]).mouseleave(()=>{
    console.log("MOUSELEAVE")
    ciao.css(
        {
            "height":"0",
            "opacity":"0"
        }
    );
    // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
}); */



$(window).scroll(()=>{
    console.log("scroll")
    if($(document).scrollTop() > 100){
        cvociHeader.css(
            {
                "position" : "fixed",
                "top" : "0",
                
            }
        );
    } else{
        cvociHeader.css(
            {
                "position" : "absolute",
                "top" : "100%",
            }
        );
    }
})



// Gestione bottoni slider
const slider = $(".contenitore-slider ul");
const bottoniSinistra = $(".bottone-slider.sinistra");
const bottoniDestra = $(".bottone-slider.destra");
console.log("Slider" , slider);
console.log("Bottoni sinistra", bottoniSinistra);
console.log("Bottoni destra", bottoniDestra);
// console.log(bottone);
console.log(bottoniSinistra[0]);

for(let i=0; i<slider.length; i++){
    let maxScrollWidth = slider[i].scrollWidth - slider[i].clientWidth;
    console.log("scrollWidth " + i + ":", slider[i].scrollWidth, slider[i]);
    console.log("maxScrollSlider: ", maxScrollWidth)
    
    /* Per lo scorrimento dallo scrollbar */
    $(slider[i]).scroll(()=>{
        console.log(slider[i].scrollLeft)
        if(slider[i].scrollLeft == 0){
            bottoniSinistra[i].disabled = true;
        } else bottoniSinistra[i].disabled = false;

        if(parseInt(slider[i].scrollLeft) >= maxScrollWidth){
            bottoniDestra[i].disabled = true;
        } else bottoniDestra[i].disabled = false;
        
    });
    
    $(bottoniSinistra[i]).click(()=>{
        console.log("Tasto sinistro");
        
        if(slider[i].scrollLeft == 0){
            bottoniSinistra[i].disabled = true;
        } else {
            bottoniSinistra[i].disabled = false;
            switch(i){

                case 0:
                    slider[i].scrollLeft -= (slider[i].scrollWidth / 8) + 12;
                    break;
                case 1:
                    slider[i].scrollLeft -= (slider[i].scrollWidth / 7) + 12;
                    break;
                case 2:
                    slider[i].scrollLeft -= (slider[i].scrollWidth / 6) + 12;
                    break;
                default:
                    slider[i].scrollLeft -= 300;
            }
            
        }
        
    });

    $(bottoniDestra[i]).click(()=>{
        console.log("Tasto destro");

        if(parseInt(slider[i].scrollLeft) >= maxScrollWidth){
            bottoniDestra[i].disabled = true;
        } else {
            bottoniDestra[i].disabled = false;
            switch(i){

                case 0:
                    slider[i].scrollLeft += (slider[i].scrollWidth / 9) + 12;
                    break;
                case 1:
                    slider[i].scrollLeft += (slider[i].scrollWidth / 7) + 12;
                    break;
                case 2:
                    slider[i].scrollLeft += (slider[i].scrollWidth / 6) + 12;
                    break;
                default:
                    slider[i].scrollLeft += 300;
            }
            
        }
    });
}