// // Script principale
// let CAIO = document.querySelector("#mini-header nav ul li:nth-child(2)");
// console.log(CAIO.innerHTML);

// $(CAIO).hover(()=>{
//     $("#contenitore-mini-voci")
//     .css("opacity", "1")
//     .css("z-index", "100")
//     // .css("transition", "opacity 250ms, transform 250ms");
// });

// console.log($("#contenitore-mini-voci").html());

// let miniVoci = $("#contenitore-mini-voci");

// $(miniVoci).mouseout(()=>{
//     $(miniVoci)
//     .css("opacity", "0")
//     .css("z-index", "-1");
// });


let ciao = 1;

console.log(ciao);
