// // Script principale
// let CAIO = document.querySelector("#mini-header nav ul li:nth-child(2)");
// console.log(CAIO.innerHTML);

// $(CAIO).hover(()=>{
//     $("#contenitore-mini-voci")
//     .css("opacity", "1")
//     .css("z-index", "100")
//     // .css("transition", "opacity 250ms, transform 250ms");
// });

// console.log($("#contenitore-mini-voci").html());

// let miniVoci = $("#contenitore-mini-voci");

// $(miniVoci).mouseout(()=>{
//     $(miniVoci)
//     .css("opacity", "0")
//     .css("z-index", "-1");
// });

const vociHeader = $(".voce-grande-header");
let cvociHeader = $(".contenitore-voci-header");

for(let i=0; i<vociHeader.length;i++){
    console.log(vociHeader[i].innerHTML);
    $(vociHeader[i]).hover(()=>{
        console.log("HOVER")
        
        cvociHeader.css(
            {
                "height":"340px",
                "opacity":"1",
                "z-index":"100",
                "top":"96px",
            });
    
        // ciao.animate({}, 300);
        // $("#voce-header-uomo").css("opacity","1").fadeIn(350);
    
        // $(bb[1]).mouseleave(()=>{
        //     console.log("MOUSELEAVE")
        //     ciao.css(
        //         {
        //             "height":"0",
        //             "opacity":"0"
        //         }
        //     );
        //     // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
        // });

        $(vociHeader[i]).css("opacity", "1")
        
    });
    
    $(cvociHeader).mouseleave(()=>{
        console.log("MOUSELEAVE")
        
        $(vociHeader[i]).css("opacity", "0");
        
        cvociHeader.css(
            {
                "height":"0",
                "opacity":"0"
            }
        );
        // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
    });
}





/* $(bb[1]).mouseleave(()=>{
    console.log("MOUSELEAVE")
    ciao.css(
        {
            "height":"0",
            "opacity":"0"
        }
    );
    // $("#voce-header-uomo").css("opacity","0").fadeOut(350);
}); */



$(document).scroll(()=>{
    console.log("scroll")
    if($(document).scrollTop() > 50){
        cvociHeader.css(
            {
                "position" : "sticky",
                "top" : "0",
            }
        );
    } else{
        cvociHeader.css(
            {
                "position" : "absolute",
                "top" : "96px",
            }
        );
    }
})



// Gestione bottoni slider
