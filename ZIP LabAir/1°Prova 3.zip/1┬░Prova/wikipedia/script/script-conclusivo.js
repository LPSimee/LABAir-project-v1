$(function(){


    console.log($("a"));

    $("a").css("color","green");

    var linkScelto;

    $("a").click(function(e){
        e.preventDefault();
        //$("#popup").css("display","block");

        $("#popup").fadeIn(1500);
        linkScelto=$(this).attr("href"); //qui leggo il contenuto href del tag a cliccato


    });

    $("#popup button").click(function(){
        console.log($(this));

        if($(this).text()=="NO"){
            $("#popup").fadeOut(1000);
        }
        else{
            console.log(linkScelto);
            location.href="https://it.wikipedia.org"+linkScelto;
        }

    });




});//.ready